function buttonClicked(buttonId) {
    var display = document.getElementById('calculator__display');
    var buttonValue = document.getElementById(buttonId).innerText;
    switch(buttonId) {
        case 'B0':
            // Code for button 0
            break;
        case 'B1':
            display.innerHTML = buttonValue;
            break;
        case 'B2':
            // Code for button 2
            break;
        case 'B3':
            // Code for button 3
            break;
        case 'B4':
            // Code for button 4
            break;
        case 'B5':
            // Code for button 5
            break;
        case 'B6':
            // Code for button 6
            break;
        case 'B7':
            // Code for button 7
            break;
        case 'B8':
            // Code for button 8
            break;
        case 'B9':
            // Code for button 9
            break;
        case 'BAC':
            // Code for button AC
            break;
        case 'BToggle':
            // Code for button +/-
            break;
        case 'BPR':
            // Code for button %
            break;
        case 'BDV':
            // Code for button ÷
            break;
        case 'BX':
            // Code for button x
            break;
        case 'BMinus':
            // Code for button -
            break;
        case 'BPlus':
            // Code for button +
            break;
        case 'BComma':
            // Code for button .
            break;
        case 'BEqual':
            // Code for button =
            break;
        default:
            console.log('Invalid button');
    }
}